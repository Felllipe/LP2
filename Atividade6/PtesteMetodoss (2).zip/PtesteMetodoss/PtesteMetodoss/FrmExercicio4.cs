﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodoss
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracterNumerico_Click(object sender, EventArgs e)
        {
            int i;
            int CaracterNumerico;
            string Mensagem;
            char posicao;

            CaracterNumerico = 0;

            for (i = 0; i < richTextBox1.Text.Length; i++)
            {
                posicao = richTextBox1.Text[i];
                if (Char.IsNumber(posicao))
                    CaracterNumerico = CaracterNumerico + 1;
            }
           Mensagem = CaracterNumerico.ToString();
            MessageBox.Show(Mensagem);
        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            int i;
            int Pbranco;
            string mensagem;
            string mensagemN;
            char posicao;

            i = 0;
            Pbranco = 0;
            mensagemN = "Não tem espaços em branco";

            while (i < richTextBox1.Text.Length)
            {
                posicao = richTextBox1.Text[i];

                if (Char.IsWhiteSpace(posicao))
                {
                    Pbranco = i + 1;
                    mensagem = Pbranco.ToString();
                    MessageBox.Show(mensagem);
                    break;
                }
                else
                    i++;
            }
            if (i >= richTextBox1.Text.Length)
                MessageBox.Show(mensagemN);
        }

        private void btnQuantosCaracter_Click(object sender, EventArgs e)
        {
            int QuantosCaracterTem;
            string mensagem;

            QuantosCaracterTem = 0;

            foreach (Char posicao in richTextBox1.Text)
            {
                if (Char.IsLetter(posicao))
                    QuantosCaracterTem = QuantosCaracterTem + 1;
            }
            mensagem = QuantosCaracterTem.ToString();
            MessageBox.Show(mensagem);
        }
    }
    
    
}
