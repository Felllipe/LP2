﻿namespace PtesteMetodoss
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnCaracterNumerico = new System.Windows.Forms.Button();
            this.btnPrimeiroBranco = new System.Windows.Forms.Button();
            this.btnQuantosCaracter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(142, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(503, 226);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnCaracterNumerico
            // 
            this.btnCaracterNumerico.Location = new System.Drawing.Point(103, 322);
            this.btnCaracterNumerico.Name = "btnCaracterNumerico";
            this.btnCaracterNumerico.Size = new System.Drawing.Size(157, 57);
            this.btnCaracterNumerico.TabIndex = 1;
            this.btnCaracterNumerico.Text = "Quantos Caracter Numericos";
            this.btnCaracterNumerico.UseVisualStyleBackColor = true;
            this.btnCaracterNumerico.Click += new System.EventHandler(this.btnCaracterNumerico_Click);
            // 
            // btnPrimeiroBranco
            // 
            this.btnPrimeiroBranco.Location = new System.Drawing.Point(342, 322);
            this.btnPrimeiroBranco.Name = "btnPrimeiroBranco";
            this.btnPrimeiroBranco.Size = new System.Drawing.Size(157, 57);
            this.btnPrimeiroBranco.TabIndex = 2;
            this.btnPrimeiroBranco.Text = "Primeiro Caracter Branco";
            this.btnPrimeiroBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroBranco.Click += new System.EventHandler(this.btnPrimeiroBranco_Click);
            // 
            // btnQuantosCaracter
            // 
            this.btnQuantosCaracter.Location = new System.Drawing.Point(579, 322);
            this.btnQuantosCaracter.Name = "btnQuantosCaracter";
            this.btnQuantosCaracter.Size = new System.Drawing.Size(157, 57);
            this.btnQuantosCaracter.TabIndex = 3;
            this.btnQuantosCaracter.Text = "Quantos Caracter tem";
            this.btnQuantosCaracter.UseVisualStyleBackColor = true;
            this.btnQuantosCaracter.Click += new System.EventHandler(this.btnQuantosCaracter_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 469);
            this.Controls.Add(this.btnQuantosCaracter);
            this.Controls.Add(this.btnPrimeiroBranco);
            this.Controls.Add(this.btnCaracterNumerico);
            this.Controls.Add(this.richTextBox1);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnCaracterNumerico;
        private System.Windows.Forms.Button btnPrimeiroBranco;
        private System.Windows.Forms.Button btnQuantosCaracter;
    }
}