﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodoss
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnteste_Click(object sender, EventArgs e)
        {
            if (string.Compare(txt1.Text, txt2.Text, true)== 0)
            {
                MessageBox.Show("São iguais!");
            }

            else
                MessageBox.Show("São diferentes!");
        }

        private void btnTxt1_Click(object sender, EventArgs e)
        {
            int metade = txt2.Text.Length / 2 ;

            txt2.Text = txt2.Text.Substring(0, metade) + txt1.Text + txt2.Text.Substring(metade, txt2.Text.Length - metade);

             
        }

        private void btnAsteriscos_Click(object sender, EventArgs e)
        {
            int meio = txt1.Text.Length / 2;
            txt2.Text = txt1.Text.Insert(meio, "**");
        }
    }
}
