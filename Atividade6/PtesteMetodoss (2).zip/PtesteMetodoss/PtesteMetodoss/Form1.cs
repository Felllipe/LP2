﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodoss
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmExercicio2"];
            if ( fc != null )
                 fc.Close();

            FrmExercicio2 Frm2 = new FrmExercicio2(); // criando objeto
            Frm2.MdiParent = this;
            Frm2.WindowState = FormWindowState.Maximized;
            Frm2.Show(); // mostrar objeto // metodo
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                Form fc = Application.OpenForms["frmExercicio3"];
                if (fc != null)
                    fc.Close();

                FrmExercicio3 Frm3 = new FrmExercicio3(); // criando objeto
                Frm3.MdiParent = this;
                Frm3.WindowState = FormWindowState.Maximized;
                Frm3.Show(); // mostrar objeto // metodo
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                Form fc = Application.OpenForms["frmExercicio4"];
                if (fc != null)
                    fc.Close();

                FrmExercicio4 Frm4 = new FrmExercicio4(); // criando objeto
                Frm4.MdiParent = this;
                Frm4.WindowState = FormWindowState.Maximized;
                Frm4.Show(); // mostrar objeto // metodo
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                Form fc = Application.OpenForms["frmExercicio5"];
                if (fc != null)
                    fc.Close();

                FrmExercicio5 Frm5 = new FrmExercicio5(); // criando objeto
                Frm5.MdiParent = this;
                Frm5.WindowState = FormWindowState.Maximized;
                Frm5.Show(); // mostrar objeto // metodo
            }
        }

        private void copiarCrtlCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Teclou Crtl + C");
        }

        private void colarCrtlVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("teclouu Crtl + V");
        }
    }
}
