﻿namespace PAtividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnNumEspacBran = new System.Windows.Forms.Button();
            this.btnNumLetraR = new System.Windows.Forms.Button();
            this.btnNumParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(145, 34);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(305, 143);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // btnNumEspacBran
            // 
            this.btnNumEspacBran.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNumEspacBran.Location = new System.Drawing.Point(145, 251);
            this.btnNumEspacBran.Name = "btnNumEspacBran";
            this.btnNumEspacBran.Size = new System.Drawing.Size(75, 85);
            this.btnNumEspacBran.TabIndex = 2;
            this.btnNumEspacBran.Text = "Número de espaços em branco";
            this.btnNumEspacBran.UseVisualStyleBackColor = false;
            this.btnNumEspacBran.Click += new System.EventHandler(this.btnNumEspacBran_Click);
            // 
            // btnNumLetraR
            // 
            this.btnNumLetraR.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNumLetraR.Location = new System.Drawing.Point(261, 251);
            this.btnNumLetraR.Name = "btnNumLetraR";
            this.btnNumLetraR.Size = new System.Drawing.Size(75, 85);
            this.btnNumLetraR.TabIndex = 3;
            this.btnNumLetraR.Text = "Número de letras R";
            this.btnNumLetraR.UseVisualStyleBackColor = false;
            this.btnNumLetraR.Click += new System.EventHandler(this.btnNumLetraR_Click);
            // 
            // btnNumParLetras
            // 
            this.btnNumParLetras.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNumParLetras.Location = new System.Drawing.Point(375, 251);
            this.btnNumParLetras.Name = "btnNumParLetras";
            this.btnNumParLetras.Size = new System.Drawing.Size(75, 85);
            this.btnNumParLetras.TabIndex = 4;
            this.btnNumParLetras.Text = "Número de um mesmo par de letra";
            this.btnNumParLetras.UseVisualStyleBackColor = false;
            this.btnNumParLetras.Click += new System.EventHandler(this.btnNumParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 483);
            this.Controls.Add(this.btnNumParLetras);
            this.Controls.Add(this.btnNumLetraR);
            this.Controls.Add(this.btnNumEspacBran);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "Exercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnNumEspacBran;
        private System.Windows.Forms.Button btnNumLetraR;
        private System.Windows.Forms.Button btnNumParLetras;
    }
}