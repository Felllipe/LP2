﻿namespace PAtividade8
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.lblMatri = new System.Windows.Forms.Label();
            this.txtMatri = new System.Windows.Forms.TextBox();
            this.lblProd = new System.Windows.Forms.Label();
            this.txtProd = new System.Windows.Forms.TextBox();
            this.lblGrati = new System.Windows.Forms.Label();
            this.txtGrati = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.cbxCargo = new System.Windows.Forms.ComboBox();
            this.lblSalario = new System.Windows.Forms.Label();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(111, 32);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(35, 13);
            this.lblNomeFunc.TabIndex = 1;
            this.lblNomeFunc.Text = "Nome";
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(176, 32);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(100, 20);
            this.txtNomeFunc.TabIndex = 2;
            // 
            // lblMatri
            // 
            this.lblMatri.AutoSize = true;
            this.lblMatri.Location = new System.Drawing.Point(111, 71);
            this.lblMatri.Name = "lblMatri";
            this.lblMatri.Size = new System.Drawing.Size(52, 13);
            this.lblMatri.TabIndex = 3;
            this.lblMatri.Text = "Matrícula";
            // 
            // txtMatri
            // 
            this.txtMatri.Location = new System.Drawing.Point(176, 68);
            this.txtMatri.Name = "txtMatri";
            this.txtMatri.Size = new System.Drawing.Size(100, 20);
            this.txtMatri.TabIndex = 4;
            // 
            // lblProd
            // 
            this.lblProd.AutoSize = true;
            this.lblProd.Location = new System.Drawing.Point(111, 111);
            this.lblProd.Name = "lblProd";
            this.lblProd.Size = new System.Drawing.Size(53, 13);
            this.lblProd.TabIndex = 5;
            this.lblProd.Text = "Produção";
            // 
            // txtProd
            // 
            this.txtProd.Location = new System.Drawing.Point(176, 104);
            this.txtProd.Name = "txtProd";
            this.txtProd.Size = new System.Drawing.Size(100, 20);
            this.txtProd.TabIndex = 6;
            // 
            // lblGrati
            // 
            this.lblGrati.AutoSize = true;
            this.lblGrati.Location = new System.Drawing.Point(319, 35);
            this.lblGrati.Name = "lblGrati";
            this.lblGrati.Size = new System.Drawing.Size(64, 13);
            this.lblGrati.TabIndex = 7;
            this.lblGrati.Text = "Gratificação";
            // 
            // txtGrati
            // 
            this.txtGrati.Location = new System.Drawing.Point(380, 29);
            this.txtGrati.Name = "txtGrati";
            this.txtGrati.Size = new System.Drawing.Size(100, 20);
            this.txtGrati.TabIndex = 8;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(495, 35);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(35, 13);
            this.lblCargo.TabIndex = 9;
            this.lblCargo.Text = "Cargo";
            // 
            // cbxCargo
            // 
            this.cbxCargo.FormattingEnabled = true;
            this.cbxCargo.Items.AddRange(new object[] {
            "Setor 1",
            "Setor 2",
            "Setor 3",
            "Setor 4",
            "Setor 5",
            "Setor 6",
            "Setor 7",
            "Setor 8"});
            this.cbxCargo.Location = new System.Drawing.Point(536, 29);
            this.cbxCargo.Name = "cbxCargo";
            this.cbxCargo.Size = new System.Drawing.Size(121, 21);
            this.cbxCargo.TabIndex = 10;
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(319, 75);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(39, 13);
            this.lblSalario.TabIndex = 11;
            this.lblSalario.Text = "Salário";
            // 
            // txtSalario
            // 
            this.txtSalario.Enabled = false;
            this.txtSalario.Location = new System.Drawing.Point(380, 68);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 12;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(114, 171);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 13;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 316);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.cbxCargo);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtGrati);
            this.Controls.Add(this.lblGrati);
            this.Controls.Add(this.txtProd);
            this.Controls.Add(this.lblProd);
            this.Controls.Add(this.txtMatri);
            this.Controls.Add(this.lblMatri);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.lblNomeFunc);
            this.Name = "frmExercicio4";
            this.Text = "Exercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.Label lblMatri;
        private System.Windows.Forms.TextBox txtMatri;
        private System.Windows.Forms.Label lblProd;
        private System.Windows.Forms.TextBox txtProd;
        private System.Windows.Forms.Label lblGrati;
        private System.Windows.Forms.TextBox txtGrati;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.ComboBox cbxCargo;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Button btnCalcular;
    }
}