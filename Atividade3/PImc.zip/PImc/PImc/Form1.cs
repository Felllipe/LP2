﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Altura, Peso, Imc;

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(TxtPeso.Text,out Peso))
            {
                MessageBox.Show("Valor Invalido");
            }
            else 
                if (Peso == 0)
            {
                MessageBox.Show("Valor nao pode ser zero");
            }
            if ( Peso > 400)
            {
                MessageBox.Show("Peso invalido");
            }

        }

        private void butLimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Text = "";
            TxtPeso.Text = "";
            TxtImc.Text = "";
        }

        private void butCalcular_Click(object sender, EventArgs e)

        {

            if (double.TryParse(TxtPeso.Text, out Peso) && double.TryParse(TxtAltura.Text, out Altura)) 
            {
                Imc = Peso / Math.Pow(Altura, 2);
                Imc = Math.Round(Imc, 1);
                TxtImc.Text = Imc.ToString();


                if (Imc < 18.5)
                {
                    MessageBox.Show("Magreza");
                }
                else 
                if (Imc <= 24.9)
                {
                    MessageBox.Show("Normal");
                }
                else
                if (Imc <= 29.9)
                {
                    MessageBox.Show("Sobrepeso");
                }
                else
                if (Imc <= 39.9)
                {
                    MessageBox.Show("Obesidade");
                }

                else if(Imc >= 40)
                {
                    MessageBox.Show("Obesidade Grave");
                }
            }

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
            {
                if (!double.TryParse(TxtAltura.Text, out Altura))
                {
                    MessageBox.Show("Valor Invalido");
                }
                else
                    if (Altura == 0)
                {
                    MessageBox.Show("Valor não pode ser zero");
                }
            if (Altura >= 5)
            {
                MessageBox.Show("Altura Invalida usar virgula para altura");
            }
        }
    }
}
