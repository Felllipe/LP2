﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadorSimples
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Validated(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox1.Text, out Numero1))

            {
                MessageBox.Show("Valor invalido");
                textBox1.Focus();
            }
            else
                if (Numero1 == 0)
            {
                MessageBox.Show(" Valor não pode ser zero!");
                textBox1.Focus();
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox2.Text, out Numero2))

            {
                MessageBox.Show("Valor invalido");
                textBox2.Focus();
            }
            else
                if (Numero2 == 0)
            {
                MessageBox.Show(" Valor não pode ser zero!");
                textBox2.Focus();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out Numero1) && double.TryParse(textBox2.Text, out Numero2))
            {
                Resultado = Numero1 - Numero2;
                textBox3.Text = Resultado.ToString();
            }

            else
            {
             MessageBox.Show("Numeros invalidos!");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out Numero1) && double.TryParse(textBox2.Text, out Numero2))
            {
                Resultado = Numero1 * Numero2;
                textBox3.Text = Resultado.ToString();
            }

            else
            {
                MessageBox.Show("Numeros invalidos!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out Numero1) && double.TryParse(textBox2.Text, out Numero2))
            {
                if (Numero2 == 0)
                MessageBox.Show("Valor não pode ser igual a zero");

                  else
                {
                    Resultado = Numero1 / Numero2;
                    textBox3.Text = Resultado.ToString();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            if (double.TryParse(textBox1.Text, out Numero1) && double.TryParse(textBox2.Text, out Numero2))
            {
                Resultado = Numero1 + Numero2;
                textBox3.Text = Resultado.ToString();
            }

            else
            {
                MessageBox.Show("Numeros invalidos!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
