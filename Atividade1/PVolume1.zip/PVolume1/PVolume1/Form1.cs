﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            double raio;
            if (!double.TryParse(textBox1.Text, out raio))

            {
                MessageBox.Show("Valor raio invalido");
                //textBox1.Focus();
            }
            else
                if (raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero!");
                //textBox1.Focus();
            }
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {

            double Altura;
            if (!double.TryParse(textBox2.Text, out Altura))

            {
                MessageBox.Show("Altura invalida!");
                //textBox2.Focus();
            }
            else
                if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior do que zero!");
                //textBox2.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double raio;
            if (!double.TryParse(textBox1.Text, out raio))

            {
                MessageBox.Show("Valor raio invalido");
                textBox1.Focus();
            }
            else
                if (raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero!");
                textBox1.Focus();
            }
            else
            {
                double Altura;
                if (!double.TryParse(textBox2.Text, out Altura))

                {
                    MessageBox.Show("Altura invalida!");
                    textBox2.Focus();
                }
                else
                      if (Altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior do que zero!");
                    textBox2.Focus();
                }

                else

                {
                    double volume;
                    volume = Math.PI * Math.Pow(raio, 2) * Altura;
                    textBox3.Text = volume.ToString("N2");
                }
            }
        }
    }
}

