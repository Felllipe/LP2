﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        string ssoltCasad, snomeFunc, sSrSra, sdoDa, snumFilh;
        double SalBruto, SalFam, SalLiq, DescINSS, DescIRPF, Func;

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNome.Text, out Func))
            {
                MessageBox.Show("Nome inválido");
                
            }
            else
            if (txtNome.Text == "" || txtNome.Text == " ")
            {
                MessageBox.Show("Nome Inválido");
                txtNome.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            cbNumeroFilhos.Text = "0";
            txtNome.Clear();
            mskbxSalarioBruto.Clear();
            txtAliquotaInss.Clear();
            txtAliquotaIrpf.Clear();
            txtDescInss.Clear();
            txtAliquotaIrpf.Clear();
            txtSalFamilia.Clear();
            txtSalLiquido.Clear();
            txtDescIrpf.Clear();
        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
            
                if (!double.TryParse(mskbxSalarioBruto.Text, out SalBruto))
                {
                    MessageBox.Show("Salário Inválido");
                    mskbxSalarioBruto.Focus();
                }
                else
                    if (SalBruto <= 0)
                {
                    MessageBox.Show("Salário deve ser maior que zero");
                
            }

            
        }
                

        private void btVerificarDesconto_Click(object sender, EventArgs e)
        {
            {
                if (SalBruto <= 800.47)
                {
                    txtAliquotaInss.Text = "7,65%";
                    DescINSS = 0.0765 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                       if (SalBruto <= 1050)
                {
                    txtAliquotaInss.Text = "8,65%";
                    DescINSS = 0.0865 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                       if (SalBruto <= 1400.77)
                {
                    txtAliquotaInss.Text = "9,00%";
                    DescINSS = 0.0900 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                  if (SalBruto <= 2801.56)
                {
                    txtAliquotaInss.Text = "11,00%";
                    DescINSS = 0.110 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                {
                    txtAliquotaInss.Text = "Teto";
                    DescINSS = 308.17;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                if (SalBruto <= 1257.12)
                {
                    txtAliquotaIrpf.Text = "Isento";
                    DescIRPF = 0 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                else
                     if (SalBruto <= 2512.08)
                {
                    txtAliquotaIrpf.Text = "15,00%";
                    DescIRPF = 0.15 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                else
                {
                    txtAliquotaIrpf.Text = "27,00%";
                    DescIRPF = 0.275 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                if (SalBruto <= 435.52)
                {
                    SalFam = 22.33 * Convert.ToDouble(cbNumeroFilhos.Text);
                    txtSalFamilia.Text = SalFam.ToString("f2");
                }
                else
                         if (SalBruto <= 654.74)
                {
                    SalFam = 15.74 * Convert.ToDouble(cbNumeroFilhos.Text);
                    txtSalFamilia.Text = SalFam.ToString("f2");
                }
                else

                    txtSalFamilia.Text = "Não se enquadra";

                SalLiq = SalBruto - DescINSS - DescIRPF + SalFam;
                txtSalLiquido.Text = SalLiq.ToString();

                

                if (rbtnF.Checked == true)
                    sdoDa = "da";
                else
                    sdoDa = "do";

                if (rbtnF.Checked == true)
                    sSrSra = "Sra.";
                else
                    sSrSra = "Sr.";

                if (txtNome.Text != "")
                    snomeFunc = txtNome.Text;
                else
                    snomeFunc = "Erro!";
                if (rbtnF.Checked == true && cbxCasado.Checked == true)
                    ssoltCasad = "casada";
                else if (rbtnF.Checked == true && cbxCasado.Checked == false)
                    ssoltCasad = "solteira";
                else if (rbtnM.Checked == true && cbxCasado.Checked == true)
                    ssoltCasad = "casado";
                else
                    ssoltCasad = "solteiro";

                snumFilh = "-1";

                if (cbNumeroFilhos.SelectedItem != "0")
                    snumFilh = "tem " + cbNumeroFilhos.SelectedItem + " filho(s)";
                else if (cbNumeroFilhos.SelectedItem == "0")
                    snumFilh = "não tem filho(a)";

                

                lblDados.Text = "Os descontos do salário" + " " + sdoDa + " " + sSrSra + " " + snomeFunc + " " + "que é" + " " + ssoltCasad + " " + "e que" + " " + snumFilh + " " + "é: ";
            }
        }
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbNumeroFilhos.Text = "0";
            
        }
    }
    
}
