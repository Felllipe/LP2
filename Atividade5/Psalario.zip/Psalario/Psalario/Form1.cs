﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        string EstadoCivil;
        double SalBruto, SalFam, SalLiq, DescINSS, DescIRPF, Func;

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (Double.TryParse(txtNome.Text, out Func))
            {
                MessageBox.Show("Nome inválido");
                
            }
            else
            if (txtNome.Text == "" || txtNome.Text == " ")
            {
                MessageBox.Show("Nome Inválido");
                txtNome.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            cbNumeroFilhos.Text = "0";
            txtNome.Clear();
            mskbxSalarioBruto.Clear();
            txtAliquotaInss.Clear();
            txtAliquotaIrpf.Clear();
            txtDescInss.Clear();
            txtAliquotaIrpf.Clear();
        }

        private void mskbxSalarioBruto_Validated(object sender, EventArgs e)
        {
            
                if (!double.TryParse(mskbxSalarioBruto.Text, out SalBruto))
                {
                    MessageBox.Show("Salário Inválido");
                    mskbxSalarioBruto.Focus();
                }
                else
                    if (SalBruto <= 0)
                {
                    MessageBox.Show("Salário deve ser maior que zero");
                }

            
        }

        private void cbxCasado_CheckedChanged(object sender, EventArgs e)
        {
            {
                if (cbxCasado.Checked)
                {
                    EstadoCivil = "Casado";

                }
                else
                    if (!cbxCasado.Checked)
                {
                    EstadoCivil = "Solteiro";
                }
            }
        }

        private void btVerificarDesconto_Click(object sender, EventArgs e)
        {
            {
                if (SalBruto <= 800.47)
                {
                    txtAliquotaInss.Text = "7,65%";
                    DescINSS = 0.0765 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                       if (SalBruto <= 1050)
                {
                    txtAliquotaInss.Text = "8,65%";
                    DescINSS = 0.0865 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                       if (SalBruto <= 1400.77)
                {
                    txtAliquotaInss.Text = "9,00%";
                    DescINSS = 0.0900 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                  if (SalBruto <= 2801.56)
                {
                    txtAliquotaInss.Text = "11,00%";
                    DescINSS = 0.110 * SalBruto;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                else
                {
                    txtAliquotaInss.Text = "0";
                    DescINSS = 308.17;
                    txtDescInss.Text = DescINSS.ToString("f2");
                }
                if (SalBruto <= 1257.12)
                {
                    txtAliquotaIrpf.Text = "0";
                    DescIRPF = 0 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                else
                     if (SalBruto <= 2512.08)
                {
                    txtAliquotaIrpf.Text = "15,00%";
                    DescIRPF = 0.15 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                else
                {
                    txtAliquotaIrpf.Text = "27,00%";
                    DescIRPF = 0.28 * SalBruto;
                    txtDescIrpf.Text = DescIRPF.ToString("f2");
                }
                if (SalBruto <= 435.52)
                {
                    SalFam = 22.33 * Convert.ToDouble(cbNumeroFilhos.Text);
                    txtSalFamilia.Text = SalFam.ToString("f2");
                }
                else
                         if (SalBruto <= 654.74)
                {
                    SalFam = 15.74 * Convert.ToDouble(cbNumeroFilhos.Text);
                    txtSalFamilia.Text = SalFam.ToString("f2");
                }

                SalLiq = SalBruto - DescINSS - DescIRPF + SalFam;
                txtSalLiquido.Text = SalLiq.ToString();



                lblDados.Text = " O funcionário (a) " + txtNome.Text + " é " + EstadoCivil + "\n tem " + cbNumeroFilhos.Text + " filho(a)" + " tem um salário de R$ " + txtSalLiquido.Text + "\n Tem uma aliquota de INSS de " + txtAliquotaInss.Text + " \n que conrresponde ao desconto de INSS de  R$" + txtDescInss.Text;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbNumeroFilhos.Text = "0";
            
        }
    }
    
}
