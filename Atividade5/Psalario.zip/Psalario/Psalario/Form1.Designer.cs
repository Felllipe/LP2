﻿namespace Psalario
{
    partial class Form1
    {

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalario = new System.Windows.Forms.Label();
            this.LblFilhos = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliquotaInss = new System.Windows.Forms.Label();
            this.lblAliquotaIrpf = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.lblDescontoIrpf = new System.Windows.Forms.Label();
            this.grpSexo = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbxCasado = new System.Windows.Forms.CheckBox();
            this.btVerificarDesconto = new System.Windows.Forms.Button();
            this.txtAliquotaInss = new System.Windows.Forms.TextBox();
            this.txtAliquotaIrpf = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescInss = new System.Windows.Forms.TextBox();
            this.txtDescIrpf = new System.Windows.Forms.TextBox();
            this.cbNumeroFilhos = new System.Windows.Forms.ComboBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.grpSexo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(36, 34);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(93, 13);
            this.LblNome.TabIndex = 0;
            this.LblNome.Text = "Nome Funcionario";
            // 
            // LblSalario
            // 
            this.LblSalario.AutoSize = true;
            this.LblSalario.Location = new System.Drawing.Point(36, 68);
            this.LblSalario.Name = "LblSalario";
            this.LblSalario.Size = new System.Drawing.Size(67, 13);
            this.LblSalario.TabIndex = 1;
            this.LblSalario.Text = "Salario Bruto";
            // 
            // LblFilhos
            // 
            this.LblFilhos.AutoSize = true;
            this.LblFilhos.Location = new System.Drawing.Point(36, 112);
            this.LblFilhos.Name = "LblFilhos";
            this.LblFilhos.Size = new System.Drawing.Size(86, 13);
            this.LblFilhos.TabIndex = 2;
            this.LblFilhos.Text = "Numero de filhos";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(36, 226);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(52, 13);
            this.lblDados.TabIndex = 3;
            this.lblDados.Text = "LblDados";
            // 
            // lblAliquotaInss
            // 
            this.lblAliquotaInss.AutoSize = true;
            this.lblAliquotaInss.Location = new System.Drawing.Point(36, 294);
            this.lblAliquotaInss.Name = "lblAliquotaInss";
            this.lblAliquotaInss.Size = new System.Drawing.Size(73, 13);
            this.lblAliquotaInss.TabIndex = 4;
            this.lblAliquotaInss.Text = "Aliquota INSS";
            // 
            // lblAliquotaIrpf
            // 
            this.lblAliquotaIrpf.AutoSize = true;
            this.lblAliquotaIrpf.Location = new System.Drawing.Point(36, 338);
            this.lblAliquotaIrpf.Name = "lblAliquotaIrpf";
            this.lblAliquotaIrpf.Size = new System.Drawing.Size(72, 13);
            this.lblAliquotaIrpf.TabIndex = 5;
            this.lblAliquotaIrpf.Text = "Aliquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(36, 387);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalarioFamilia.TabIndex = 6;
            this.lblSalarioFamilia.Text = "Salario Familia";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(36, 432);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(72, 13);
            this.lblSalarioLiquido.TabIndex = 7;
            this.lblSalarioLiquido.Text = "Salario liquido";
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Location = new System.Drawing.Point(361, 271);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(81, 13);
            this.lblDescontoInss.TabIndex = 8;
            this.lblDescontoInss.Text = "Desconto INSS";
            // 
            // lblDescontoIrpf
            // 
            this.lblDescontoIrpf.AutoSize = true;
            this.lblDescontoIrpf.Location = new System.Drawing.Point(361, 324);
            this.lblDescontoIrpf.Name = "lblDescontoIrpf";
            this.lblDescontoIrpf.Size = new System.Drawing.Size(80, 13);
            this.lblDescontoIrpf.TabIndex = 9;
            this.lblDescontoIrpf.Text = "Desconto IRPF";
            // 
            // grpSexo
            // 
            this.grpSexo.Controls.Add(this.rbtnM);
            this.grpSexo.Controls.Add(this.rbtnF);
            this.grpSexo.Location = new System.Drawing.Point(391, 34);
            this.grpSexo.Name = "grpSexo";
            this.grpSexo.Size = new System.Drawing.Size(200, 100);
            this.grpSexo.TabIndex = 10;
            this.grpSexo.TabStop = false;
            this.grpSexo.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Location = new System.Drawing.Point(36, 62);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(34, 17);
            this.rbtnM.TabIndex = 1;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Checked = true;
            this.rbtnF.Location = new System.Drawing.Point(36, 30);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 17);
            this.rbtnF.TabIndex = 0;
            this.rbtnF.TabStop = true;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbxCasado);
            this.panel1.Location = new System.Drawing.Point(391, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 64);
            this.panel1.TabIndex = 11;
            // 
            // cbxCasado
            // 
            this.cbxCasado.AutoSize = true;
            this.cbxCasado.Location = new System.Drawing.Point(27, 26);
            this.cbxCasado.Name = "cbxCasado";
            this.cbxCasado.Size = new System.Drawing.Size(62, 17);
            this.cbxCasado.TabIndex = 0;
            this.cbxCasado.Text = "Casado";
            this.cbxCasado.UseVisualStyleBackColor = true;
            this.cbxCasado.CheckedChanged += new System.EventHandler(this.cbxCasado_CheckedChanged);
            // 
            // btVerificarDesconto
            // 
            this.btVerificarDesconto.Location = new System.Drawing.Point(177, 153);
            this.btVerificarDesconto.Name = "btVerificarDesconto";
            this.btVerificarDesconto.Size = new System.Drawing.Size(150, 43);
            this.btVerificarDesconto.TabIndex = 12;
            this.btVerificarDesconto.Text = "Verificar Desconto";
            this.btVerificarDesconto.UseVisualStyleBackColor = true;
            this.btVerificarDesconto.Click += new System.EventHandler(this.btVerificarDesconto_Click);
            // 
            // txtAliquotaInss
            // 
            this.txtAliquotaInss.Location = new System.Drawing.Point(121, 287);
            this.txtAliquotaInss.Name = "txtAliquotaInss";
            this.txtAliquotaInss.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaInss.TabIndex = 16;
            // 
            // txtAliquotaIrpf
            // 
            this.txtAliquotaIrpf.Location = new System.Drawing.Point(121, 338);
            this.txtAliquotaIrpf.Name = "txtAliquotaIrpf";
            this.txtAliquotaIrpf.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIrpf.TabIndex = 17;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Location = new System.Drawing.Point(121, 387);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalFamilia.TabIndex = 18;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Location = new System.Drawing.Point(121, 438);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiquido.TabIndex = 19;
            // 
            // txtDescInss
            // 
            this.txtDescInss.Location = new System.Drawing.Point(471, 268);
            this.txtDescInss.Name = "txtDescInss";
            this.txtDescInss.Size = new System.Drawing.Size(100, 20);
            this.txtDescInss.TabIndex = 20;
            // 
            // txtDescIrpf
            // 
            this.txtDescIrpf.Location = new System.Drawing.Point(471, 321);
            this.txtDescIrpf.Name = "txtDescIrpf";
            this.txtDescIrpf.Size = new System.Drawing.Size(100, 20);
            this.txtDescIrpf.TabIndex = 21;
            // 
            // cbNumeroFilhos
            // 
            this.cbNumeroFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNumeroFilhos.FormattingEnabled = true;
            this.cbNumeroFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25"});
            this.cbNumeroFilhos.Location = new System.Drawing.Point(187, 109);
            this.cbNumeroFilhos.Name = "cbNumeroFilhos";
            this.cbNumeroFilhos.Size = new System.Drawing.Size(121, 21);
            this.cbNumeroFilhos.TabIndex = 22;
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(177, 65);
            this.mskbxSalarioBruto.Mask = "00000";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalarioBruto.TabIndex = 24;
            this.mskbxSalarioBruto.ValidatingType = typeof(int);
            this.mskbxSalarioBruto.Validated += new System.EventHandler(this.mskbxSalarioBruto_Validated);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(177, 31);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(191, 20);
            this.txtNome.TabIndex = 25;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(373, 387);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(163, 62);
            this.btnLimpar.TabIndex = 26;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 470);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.cbNumeroFilhos);
            this.Controls.Add(this.txtDescIrpf);
            this.Controls.Add(this.txtDescInss);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliquotaIrpf);
            this.Controls.Add(this.txtAliquotaInss);
            this.Controls.Add(this.btVerificarDesconto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grpSexo);
            this.Controls.Add(this.lblDescontoIrpf);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIrpf);
            this.Controls.Add(this.lblAliquotaInss);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.LblFilhos);
            this.Controls.Add(this.LblSalario);
            this.Controls.Add(this.LblNome);
            this.Name = "Form1";
            this.Text = "FRMsalario";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpSexo.ResumeLayout(false);
            this.grpSexo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalario;
        private System.Windows.Forms.Label LblFilhos;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliquotaInss;
        private System.Windows.Forms.Label lblAliquotaIrpf;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Label lblDescontoIrpf;
        private System.Windows.Forms.GroupBox grpSexo;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbxCasado;
        private System.Windows.Forms.Button btVerificarDesconto;
        private System.Windows.Forms.TextBox txtAliquotaInss;
        private System.Windows.Forms.TextBox txtAliquotaIrpf;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescInss;
        private System.Windows.Forms.TextBox txtDescIrpf;
        private System.Windows.Forms.ComboBox cbNumeroFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnLimpar;
    }
}

