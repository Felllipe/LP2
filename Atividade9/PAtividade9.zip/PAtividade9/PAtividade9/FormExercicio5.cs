﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class FormExercicio5 : Form
    {
        public FormExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux1;
            string aux2;
            double[,] matriz1 = new double[20, 3];
            double[] vet1 = new double[20];

            vet1[0] = 0;

            for (var l = 0; l < 20; l++)
                for (var c = 0; c < 3; c++)
                {
                    aux1 = Interaction.InputBox("Digite as notas do aluno(a) " + (l + 1) + " nota " + (c + 1), "Entrada de Dados");
                    if (!double.TryParse(aux1, out matriz1[l, c]))
                    {
                        MessageBox.Show("Valor inválido");
                        c = c - 1;
                    }
                    else
                    {
                        if (c == -1)
                        {
                            c = 0;
                            vet1[l] = vet1[l] + matriz1[l, c];
                        }
                        else
                        {
                            c = c + 0;
                            vet1[l] = vet1[l] + matriz1[l, c];
                        }
                    }
                }
            aux1 = "";
            aux2 = "";

            for (int l = 0; l < 20; l++)
            {
                vet1[l] = vet1[l] / 3;
            }

            foreach (double i in matriz1)
                aux1 = aux1 + "\n" + i;
            foreach (double i in vet1)
                aux2 = aux2 + "\n" + i;

            MessageBox.Show(aux2, "Médias");
        }
    }
}
