﻿namespace PAtividade9
{
    partial class FormExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExercutar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExercutar
            // 
            this.btnExercutar.Location = new System.Drawing.Point(222, 128);
            this.btnExercutar.Name = "btnExercutar";
            this.btnExercutar.Size = new System.Drawing.Size(183, 60);
            this.btnExercutar.TabIndex = 0;
            this.btnExercutar.Text = "Executar";
            this.btnExercutar.UseVisualStyleBackColor = true;
            this.btnExercutar.Click += new System.EventHandler(this.btnExercutar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(512, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "string[] Alunos = {\"Viviane\", \"André\", \"Hélio\", \"Denise\", \"Junior\", \"Leonardo\", \"" +
    "Jose\", \"Nelma\", \"Tobby\"}; ";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(208, 81);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(237, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Ao final do laço, podemos afirmar que Total vale:";
            // 
            // FormExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 374);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExercutar);
            this.Name = "FormExercicio3";
            this.Text = "FormExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExercutar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl2;
    }
}