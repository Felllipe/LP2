﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class FormExercicio2 : Form
    {
        public FormExercicio2()
        {
            InitializeComponent();
        }

        private void btnLerDados_Click(object sender, EventArgs e)
        {
            string aux1;
            string aux2;
            int[] vet1 = new int[10];
            double[] vet2 = new double[10];
            double[] vet3 = new double[10];
            double Acumul;
            string mensagem;

            Acumul = 0;

            for (var x = 0; x < 10; x++)
            {
                aux1 = Interaction.InputBox("Digite a quantidade de Mercadoria " + (x + 1), "Entrada de Dados");
                if (!int.TryParse(aux1, out vet1[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
                aux2 = Interaction.InputBox("Digite o preço da Mercadoria: " + (x + 1), "Entrada de Dados");
                if (!double.TryParse(aux2, out vet2[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
            }
            aux1= "";
            aux2= "";

            for (var x = 0; x < 10; x++)
            {
                vet3[x] = vet1[x] * vet2[x];
                Acumul = Acumul + vet3[x];
            }

            mensagem = Acumul.ToString("N2");

            foreach (int i in vet1)
                aux1 = aux1 + "\n" + i;
            foreach (int i in vet2)
                aux2 = aux2 + "\n" + i;

            MessageBox.Show(mensagem, "Faturamento mensal: R$");
        }
    }
}
