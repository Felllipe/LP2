﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void TXTLADOB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TXTLADOB.Text, out LadoB))
            {
                MessageBox.Show("Valor lado BInvalido");
            }
            else
          if (LadoB == 0)
            {
                MessageBox.Show("Valor lado B não pode ser zero");
            }
        }

        private void TXTLADOC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TXTLADOC.Text, out LadoC))
            {
                MessageBox.Show("Valor lado C Invalido");
            }
            else
          if (LadoC == 0)
            {
                MessageBox.Show("Valor lado C não pode ser zero");
            }
        }

        private void BTCALCULAR_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TXTLADOA.Text, out LadoA) && double.TryParse(TXTLADOB.Text, out LadoB) && double.TryParse(TXTLADOC.Text, out LadoC))
            {
                if (LadoA < (LadoB + LadoC) && LadoA > Math.Abs(LadoB - LadoC) && LadoB < (LadoA + LadoC) && LadoB > Math.Abs(LadoA - LadoC) && LadoC < (LadoA + LadoB) && LadoC > Math.Abs(LadoA - LadoB))

                {  

                    if (LadoA == LadoB && LadoB == LadoC)
                        MessageBox.Show("Triangulo Equilatero");

                    else if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                        MessageBox.Show("Triangulo Isosceles");


                    else if (LadoA != LadoB && LadoB != LadoC && LadoA != LadoC)
                        MessageBox.Show("Triangulo Escaleno");

                }

                else
                    MessageBox.Show("Valor Invalido");


            }
        }
        private void BTLIMPAR_Click(object sender, EventArgs e)
        {
            TXTLADOA.Text= "";
            TXTLADOB.Text = "";
            TXTLADOC.Text = "";
            
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TXTLADOA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TXTLADOA.Text, out LadoA))
            {
                MessageBox.Show("Valor lado A Invalido");
            }
            else
            if (LadoA == 0)
            {
                MessageBox.Show("Valor lado A não pode ser zero");
            }
        }
    }
}
