﻿
namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBLADOA = new System.Windows.Forms.Label();
            this.LBLADOB = new System.Windows.Forms.Label();
            this.LBLADOC = new System.Windows.Forms.Label();
            this.TXTLADOA = new System.Windows.Forms.TextBox();
            this.TXTLADOB = new System.Windows.Forms.TextBox();
            this.TXTLADOC = new System.Windows.Forms.TextBox();
            this.BTCALCULAR = new System.Windows.Forms.Button();
            this.BTLIMPAR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LBLADOA
            // 
            this.LBLADOA.AutoSize = true;
            this.LBLADOA.Location = new System.Drawing.Point(228, 91);
            this.LBLADOA.Name = "LBLADOA";
            this.LBLADOA.Size = new System.Drawing.Size(46, 13);
            this.LBLADOA.TabIndex = 0;
            this.LBLADOA.Text = "LADO A";
            // 
            // LBLADOB
            // 
            this.LBLADOB.AutoSize = true;
            this.LBLADOB.Location = new System.Drawing.Point(228, 145);
            this.LBLADOB.Name = "LBLADOB";
            this.LBLADOB.Size = new System.Drawing.Size(46, 13);
            this.LBLADOB.TabIndex = 1;
            this.LBLADOB.Text = "LADO B";
            // 
            // LBLADOC
            // 
            this.LBLADOC.AutoSize = true;
            this.LBLADOC.Location = new System.Drawing.Point(228, 201);
            this.LBLADOC.Name = "LBLADOC";
            this.LBLADOC.Size = new System.Drawing.Size(46, 13);
            this.LBLADOC.TabIndex = 2;
            this.LBLADOC.Text = "LADO C";
            // 
            // TXTLADOA
            // 
            this.TXTLADOA.Location = new System.Drawing.Point(315, 91);
            this.TXTLADOA.Name = "TXTLADOA";
            this.TXTLADOA.Size = new System.Drawing.Size(240, 20);
            this.TXTLADOA.TabIndex = 8;
            this.TXTLADOA.Validated += new System.EventHandler(this.TXTLADOA_Validated);
            // 
            // TXTLADOB
            // 
            this.TXTLADOB.Location = new System.Drawing.Point(315, 142);
            this.TXTLADOB.Name = "TXTLADOB";
            this.TXTLADOB.Size = new System.Drawing.Size(240, 20);
            this.TXTLADOB.TabIndex = 9;
            this.TXTLADOB.Validated += new System.EventHandler(this.TXTLADOB_Validated);
            // 
            // TXTLADOC
            // 
            this.TXTLADOC.Location = new System.Drawing.Point(315, 201);
            this.TXTLADOC.Name = "TXTLADOC";
            this.TXTLADOC.Size = new System.Drawing.Size(240, 20);
            this.TXTLADOC.TabIndex = 10;
            this.TXTLADOC.Validated += new System.EventHandler(this.TXTLADOC_Validated);
            // 
            // BTCALCULAR
            // 
            this.BTCALCULAR.Location = new System.Drawing.Point(203, 338);
            this.BTCALCULAR.Name = "BTCALCULAR";
            this.BTCALCULAR.Size = new System.Drawing.Size(138, 67);
            this.BTCALCULAR.TabIndex = 13;
            this.BTCALCULAR.Text = "CALCULAR";
            this.BTCALCULAR.UseVisualStyleBackColor = true;
            this.BTCALCULAR.Click += new System.EventHandler(this.BTCALCULAR_Click);
            // 
            // BTLIMPAR
            // 
            this.BTLIMPAR.Location = new System.Drawing.Point(441, 338);
            this.BTLIMPAR.Name = "BTLIMPAR";
            this.BTLIMPAR.Size = new System.Drawing.Size(138, 67);
            this.BTLIMPAR.TabIndex = 14;
            this.BTLIMPAR.Text = "LIMPAR";
            this.BTLIMPAR.UseVisualStyleBackColor = true;
            this.BTLIMPAR.Click += new System.EventHandler(this.BTLIMPAR_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BTLIMPAR);
            this.Controls.Add(this.BTCALCULAR);
            this.Controls.Add(this.TXTLADOC);
            this.Controls.Add(this.TXTLADOB);
            this.Controls.Add(this.TXTLADOA);
            this.Controls.Add(this.LBLADOC);
            this.Controls.Add(this.LBLADOB);
            this.Controls.Add(this.LBLADOA);
            this.Name = "Form1";
            this.Text = "Descubra o triangulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBLADOA;
        private System.Windows.Forms.Label LBLADOB;
        private System.Windows.Forms.Label LBLADOC;
        private System.Windows.Forms.TextBox TXTLADOA;
        private System.Windows.Forms.TextBox TXTLADOB;
        private System.Windows.Forms.TextBox TXTLADOC;
        private System.Windows.Forms.Button BTCALCULAR;
        private System.Windows.Forms.Button BTLIMPAR;
    }
}

